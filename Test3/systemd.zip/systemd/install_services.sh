#!/bin/bash
# =============================================================================
# install_services.sh — Deploy Dexter HMS systemd services
#
# Replaces both .sh startup scripts:
#   internal_device_active_integration.sh  →  dexter-internal.target
#   external_device_active_integration.sh  →  dexter-external.target
#
# Usage:
#   sudo bash install_services.sh [--internal-only | --external-only]
#
# With no argument: installs and enables EVERYTHING.
# --internal-only:  installs only the NVR/DVR/BACS services (internal Pi).
# --external-only:  installs only the panel/serial/MQTT services (external Pi).
# =============================================================================

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SYSTEMD_DIR="/etc/systemd/system"
MODE="${1:-all}"

[[ $EUID -ne 0 ]] && { echo "Run as root: sudo bash install_services.sh"; exit 1; }

echo "=== Dexter HMS systemd installer (mode: $MODE) ==="
echo ""

# ── Service lists matching the two original .sh files ─────────────────────────
EXTERNAL_SERVICES=(
    dexter-main
    dexter-serial-comm
    dexter-serial-logger
    dexter-network-info
    dexter-mqtt
)

INTERNAL_SERVICES=(
    dexter-nvr-hikvision
    dexter-nvr-hikvision-field
    dexter-nvr-hikvision-bacs
    dexter-nvr-dahua
    dexter-nvr-cpplus
    dexter-extract-dahua
    dexter-extract-cpplus
    dexter-sd-dahua
    dexter-sd-cpplus
    dexter-sd-hikvision
    dexter-nvr-hik-lite
    dexter-rtc-hikvision
    dexter-rtc-dahua
    dexter-rtc-cpplus
    dexter-ota-restore
    dexter-rpi-task
)

# Select which services to install
case "$MODE" in
    --internal-only)
        SERVICES=("${INTERNAL_SERVICES[@]}")
        TARGETS=("dexter.target" "dexter-internal.target")
        ;;
    --external-only)
        SERVICES=("${EXTERNAL_SERVICES[@]}")
        TARGETS=("dexter.target" "dexter-external.target")
        ;;
    *)
        SERVICES=("${EXTERNAL_SERVICES[@]}" "${INTERNAL_SERVICES[@]}")
        TARGETS=("dexter.target" "dexter-internal.target" "dexter-external.target")
        ;;
esac

# ── Step 1: Copy all service and target files ─────────────────────────────────
echo "Step 1: Installing service files..."
for f in "$SCRIPT_DIR"/*.service "$SCRIPT_DIR"/*.target; do
    [[ -f "$f" ]] || continue
    fname="$(basename "$f")"
    cp "$f" "$SYSTEMD_DIR/$fname"
    chmod 644 "$SYSTEMD_DIR/$fname"
    echo "  ✓ $fname"
done

# ── Step 1b: Create required directories ─────────────────────────────────────
echo ""
echo "Step 1b: Creating required directories..."

# Log directory — services write to /var/log/dexter/
if [[ ! -d /var/log/dexter ]]; then
    mkdir -p /var/log/dexter
    chown pi:pi /var/log/dexter
    echo "  ✓ Created /var/log/dexter  (owner: pi:pi)"
else
    echo "  ✓ /var/log/dexter already exists"
fi

# Credential gate key directory
if [[ ! -d /etc/dexter ]]; then
    mkdir -p /etc/dexter
    chmod 755 /etc/dexter
    echo "  ✓ Created /etc/dexter"
else
    echo "  ✓ /etc/dexter already exists"
fi

# Credential gate key — generate only if not already present
if [[ ! -f /etc/dexter/cred_auth.key ]]; then
    python3 -c "import secrets; print(secrets.token_hex(32))" \
        | tee /etc/dexter/cred_auth.key > /dev/null
    chown root:pi /etc/dexter/cred_auth.key
    chmod 640     /etc/dexter/cred_auth.key
    echo "  ✓ Generated /etc/dexter/cred_auth.key  (root:pi, 640)"
    echo ""
    echo "  *** IMPORTANT: Copy the key below into response_tool.html ***"
    echo "  Key: $(cat /etc/dexter/cred_auth.key)"
    echo "  *** Save response_tool.html to your engineer phone with this key ***"
else
    echo "  ✓ /etc/dexter/cred_auth.key already exists — not overwritten"
fi

# Deploy credential_auth.py if present in same directory as this script
if [[ -f "$SCRIPT_DIR/credential_auth.py" ]]; then
    cp "$SCRIPT_DIR/credential_auth.py" /home/pi/Test3/credential_auth.py
    chown pi:pi /home/pi/Test3/credential_auth.py
    echo "  ✓ Deployed credential_auth.py to /home/pi/Test3/"
else
    echo "  ! credential_auth.py not found in $SCRIPT_DIR"
    echo "    Copy it manually: cp credential_auth.py /home/pi/Test3/"
fi

# ── Step 2: Reload systemd ────────────────────────────────────────────────────
echo ""
echo "Step 2: Reloading systemd daemon..."
systemctl daemon-reload

# ── Step 3: Enable targets and services ──────────────────────────────────────
echo ""
echo "Step 3: Enabling targets..."
for target in "${TARGETS[@]}"; do
    systemctl enable "$target" && echo "  ✓ Enabled: $target"
done

echo ""
echo "Step 4: Enabling services..."
for svc in "${SERVICES[@]}"; do
    systemctl enable "${svc}.service" 2>/dev/null \
        && echo "  ✓ Enabled: $svc" \
        || echo "  ✗ Skipped: $svc (file not found)"
done

# ── Step 5: Disable and stop old .sh-based startup (if present) ───────────────
echo ""
echo "Step 5: Disabling old .sh startup methods (if any)..."
# If the .sh files were called via cron or rc.local, remind the operator
if grep -q "active_integration.sh" /etc/rc.local 2>/dev/null; then
    echo "  WARNING: Found .sh reference in /etc/rc.local — please remove it:"
    grep "active_integration.sh" /etc/rc.local
fi
if crontab -l -u pi 2>/dev/null | grep -q "active_integration.sh"; then
    echo "  WARNING: Found .sh reference in pi crontab — please remove it:"
    crontab -l -u pi | grep "active_integration.sh"
fi
if crontab -l 2>/dev/null | grep -q "active_integration.sh"; then
    echo "  WARNING: Found .sh reference in root crontab — please remove it:"
    crontab -l | grep "active_integration.sh"
fi
echo "  (Nothing automatic was changed in rc.local or crontab)"

# ── Step 6: Start services ────────────────────────────────────────────────────
echo ""
echo "Step 6: Starting services..."
if ! systemctl start dexter.target; then
    echo "  ! dexter.target failed to start cleanly"
    echo "    Check: sudo journalctl -u dexter-main -n 20"
    echo "    Individual services may have failed — see status below"
else
    echo "  ✓ dexter.target started"
fi

# ── Step 7: Status summary ────────────────────────────────────────────────────
echo ""
echo "=== Status ==="
for svc in "${SERVICES[@]}"; do
    status=$(systemctl is-active "${svc}.service" 2>/dev/null || echo "unknown")
    icon="✓" ; [[ "$status" != "active" ]] && icon="✗"
    printf "  %s %-35s %s\n" "$icon" "$svc" "$status"
done

echo ""
echo "=== Done ==="
echo ""
echo "Key commands:"
echo "  sudo systemctl status dexter.target          # all services"
echo "  sudo journalctl -u dexter-main -f            # main panel logs"
echo "  sudo journalctl -u 'dexter-*' -f             # all Dexter logs"
echo "  sudo systemctl stop dexter.target            # stop everything"
echo "  sudo systemctl restart dexter-nvr-hikvision  # restart one service"
